Thank you for downloading lean launcher.
Please stay on our Discord server to receive more information and further updates.

If the launcher is closing/erroring, please install .NET 6.0.4 runtime in runtimes folder.

Please disable your antivirus because it might delete the Vape executables.

- pluto