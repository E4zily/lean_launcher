Please do not modify any of this unless you are changing settings or you know what you are doing.

If you want to launch the client, please use the lean_launcher.exe instead of going into files.

Thank you.