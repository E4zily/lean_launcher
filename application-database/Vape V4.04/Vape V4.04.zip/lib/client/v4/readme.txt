wondering why its named "svchost"? its because some clients have protection against exe files named "vape" so we renamed it

if you are missing the svchost file, your antivirus probably deleted it.