wondering why its named "taskhostw"? its because some clients have protection against exe files named "vape" so we renamed it

if you are missing the taskhostw file, your antivirus probably deleted it.